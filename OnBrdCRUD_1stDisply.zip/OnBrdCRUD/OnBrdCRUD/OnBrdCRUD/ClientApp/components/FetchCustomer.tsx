﻿import * as React from 'react';
import { RouteComponentProps } from 'react-router';
import { Link, NavLink } from 'react-router-dom';
interface FetchCustomerDataState {
    custList: CustomerData[];
    loading: boolean;
}
export class FetchCustomer extends React.Component<RouteComponentProps<{}>, FetchCustomerDataState> {
    constructor() {
        super();
        this.state = { custList: [], loading: true };
        fetch('api/Customer/Index')
            .then(response => response.json() as Promise<CustomerData[]>)
            .then(data => {
                this.setState({ custList: data, loading: false });
            });
        // This binding is necessary to make "this" work in the callback  
        this.handleDelete = this.handleDelete.bind(this);
        this.handleEdit = this.handleEdit.bind(this);
    }
    public render() {
        let contents = this.state.loading
            ? <p><em>Loading...</em></p>
            : this.renderCustomerTable(this.state.custList);
        return <div>
            <h1>Customer Data</h1>
            <p>This component demonstrates fetching Customer data from the server.</p>
            <p>
                <Link to="/addcustomer">Create New</Link>
            </p>
            {contents}
        </div>;
    }
    // Handle Delete request for a Customer
    private handleDelete(id: number) {
        if (!confirm("Do you want to delete Customer with Id: " + id))
            return;
        else {
            fetch('api/Customer/Delete/' + id, {
                method: 'delete'
            }).then(data => {
                this.setState(
                    {
                        custList: this.state.custList.filter((rec) => {
                            return (rec.id != id);
                        })
                    });
            });
        }
    }
    private handleEdit(id: number) {
        this.props.history.push("/customer/edit/" + id);
    }
    // Returns the HTML table to the render() method.  
    private renderCustomerTable(custList: CustomerData[]) {
        return <table className='table'>
            <thead>
                <tr>
                    <th></th>
                    <th>CustomerId</th>
                    <th>Name</th>
                    <th>Address</th>
                </tr>
            </thead>
            <tbody>
                {custList.map(cust =>
                    <tr key={cust.id}>
                        <td></td>
                        <td>{cust.name}</td>
                        <td>{cust.Address}</td>
                        <td>
                            <a className="action" onClick={(id) => this.handleEdit(cust.id)}>Edit</a>  |
                            <a className="action" onClick={(id) => this.handleDelete(cust.id)}>Delete</a>
                        </td>
                    </tr>
                )}
            </tbody>
        </table>;
    }
}
export class CustomerData {
    id: number = 0;
    name: string = "";
    Address: string = "";
}