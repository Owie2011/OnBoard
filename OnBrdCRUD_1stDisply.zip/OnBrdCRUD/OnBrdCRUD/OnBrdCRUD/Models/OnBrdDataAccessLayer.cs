﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnBrdCRUD.Models
{
    public class OnBrdDataAccessLayer
    {
        IC_MVP2Context db = new IC_MVP2Context();
        public IEnumerable<Customer> GetAllCustomer()
        {
            try
            {
                return db.Customer.ToList();
            }
            catch
            {
                throw;
            }
        }
        //To Add new Customer record     
        public int AddCustomer(Customer customer)
        {
            try
            {
                db.Customer.Add(customer);
                db.SaveChanges();
                return 1;
            }
            catch
            {
                throw;
            }
        }
        //To Update the records of a particluar Customer    
        public int UpdateCustomer(Customer customer)
        {
            try
            {
                db.Entry(customer).State = EntityState.Modified;
                db.SaveChanges();
                return 1;
            }
            catch
            {
                throw;
            }
        }
        //Get the details of a particular Customer    
        public Customer GetCustomer(int id)
        {
            try
            {
                Customer customer = db.Customer.Find(id);
                return customer;
            }
            catch
            {
                throw;
            }
        }
        //To Delete the record of a particular Customer    
        public int DeleteCustomer(int id)
        {
            try
            {
                Customer cust = db.Customer.Find(id);
                db.Customer.Remove(cust);
                db.SaveChanges();
                return 1;
            }
            catch
            {
                throw;
            }
        }
        ////To Get the list of Cities    
        //public List<TblCities> GetCities()
        //{
        //    List<TblCities> lstCity = new List<TblCities>();
        //    lstCity = (from CityList in db.TblCities select CityList).ToList();
        //    return lstCity;
        //}
    }
}
